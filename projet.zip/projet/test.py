import smtplib
from email.mime.text import MIMEText
import ssl

def envoyer_email_test(destinataire, expediteur, mot_de_passe):
    """
    Tente d'envoyer un e-mail de test.
    """
    sujet = "Test d'envoi d'email depuis Python"
    message_corps = """Bonjour,

Ceci est un e-mail de test envoyé depuis un script Python.
Si vous recevez cet e-mail, cela signifie que la configuration SMTP fonctionne correctement.

Cordialement,
Votre programme de test
"""

    msg = MIMEText(message_corps)
    msg["Subject"] = sujet
    msg["From"] = expediteur
    msg["To"] = destinataire

    # Utilisation du contexte SSL par défaut pour plus de sécurité
    context = ssl.create_default_context()

    try:
        print(f"Tentative de connexion à smtp.gmail.com sur le port 465...")
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as serveur:
            print(f"Connexion établie. Tentative d'authentification pour {expediteur}...")
            serveur.login(expediteur, mot_de_passe)
            print("Authentification réussie. Envoi de l'e-mail...")
            serveur.send_message(msg)
            print("E-mail envoyé avec succès !")
            return True
    except smtplib.SMTPAuthenticationError:
        print("\nERREUR : Échec de l'authentification. Vérifiez l'expéditeur et le mot de passe.")
        print("Pour Gmail, assurez-vous d'utiliser un mot de passe d'application si la validation en deux étapes est activée.")
        return False
    # CORRECTION ICI : SMTPSenderRefused au lieu de SMTPEmailSenderRefused
    except smtplib.SMTPSenderRefused as e: 
        print(f"\nERREUR : Le serveur a refusé l'expéditeur ou le destinataire: {e}")
        return False
    except smtplib.SMTPConnectError as e:
        print(f"\nERREUR : Impossible de se connecter au serveur SMTP: {e}")
        print("Vérifiez l'adresse du serveur et le port. Assurez-vous que votre connexion internet n'est pas bloquée par un pare-feu.")
        return False
    except Exception as e:
        print(f"\nUNE ERREUR INCONNUE S'EST PRODUITE : {e}")
        print("Cela pourrait être un problème de connexion réseau, de pare-feu, ou une configuration incorrecte.")
        return False

# --- Informations à remplir ---
EMAIL_EXPEDITEUR = "btssnfourcade2@gmail.com"
# ASSURE-TOI QUE C'EST LE MOT DE PASSE D'APPLICATION GÉNÉRÉ PAR GMAIL, PAS TON MOT DE PASSE HABITUEL
EMAIL_MOT_DE_PASSE = "qvxt dirt ztwu garx" # REMPLACE CECI PAR LE VRAI MOT DE PASSE D'APPLICATION
EMAIL_DESTINATAIRE = "polaszykanthony702@gmail.com"

# Exécute le test
if __name__ == "__main__":
    print("--- Démarrage du test d'envoi d'e-mail ---")
    success = envoyer_email_test(EMAIL_DESTINATAIRE, EMAIL_EXPEDITEUR, EMAIL_MOT_DE_PASSE)
    if success:
        print("\nTest réussi : L'e-mail a été envoyé.")
    else:
        print("\nTest échoué : L'e-mail n'a PAS été envoyé. Voir les messages d'erreur ci-dessus.")
    print("--- Fin du test ---")