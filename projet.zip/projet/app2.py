from flask import Flask, render_template, request, redirect, url_for, session, flash, make_response  # Import make_response
import os
from werkzeug.security import generate_password_hash, check_password_hash
import time
import smtplib
from email.mime.text import MIMEText
import secrets
import configparser
import shutil
import logging
import os
import socket

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.static_folder = 'static'

FICHIER_UTILISATEURS = "utilisateurs.txt"
DOSSIER_CONFIG = "config"
FICHIER_CONFIG_DEFAUT = os.path.join(DOSSIER_CONFIG, "config_default.ini")
FICHIER_CONFIG_LOGIN = os.path.join(DOSSIER_CONFIG, "config_login.ini")



# Configuration du logging
logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def apiCommande(commande):
    try:
        resultat = socket.send(commande)
        return resultat
    except Exception as e:
        logging.error(f"Erreur lors de l'exécution de la commande : {commande} - {e}")
        return None
    
def lire_utilisateurs():
    utilisateurs = []
    users = apiCommande("USERS;all")
    users = users.split("$")
    for element in users :
        element = element.split(";")
        nom, prenom, email, telephone, plaques, mot_de_passe, role = element
        utilisateurs.append({
            "nom": nom,
            "prenom": prenom,
            "email": email,
            "telephone": telephone,
            "plaques_immatriculation": plaques,  # Utilise le pluriel
            "mot_de_passe": mot_de_passe,
            "role": role
        })
        
    '''if os.path.exists(FICHIER_UTILISATEURS):
        with open(FICHIER_UTILISATEURS, "r") as f:
            for ligne in f:
                ligne = ligne.strip()
                if ligne:
                    elements = ligne.split(";")
                    if len(elements) == 7:
                        nom, prenom, email, telephone, plaques, mot_de_passe, role = elements
                        plaques = plaques.split(",")  # Convertit la chaîne en liste
                        utilisateurs.append({
                            "nom": nom,
                            "prenom": prenom,
                            "email": email,
                            "telephone": telephone,
                            "plaques_immatriculation": plaques,  # Utilise le pluriel
                            "mot_de_passe": mot_de_passe,
                            "role": role
                        })'''
    return utilisateurs



def ecrire_utilisateurs(utilisateurs):
    with open(FICHIER_UTILISATEURS, "w") as f:
        for utilisateur in utilisateurs:
            plaques_str = ",".join(utilisateur['plaques_immatriculation'])  # Convertit la liste en chaîne
            f.write(f"{utilisateur['nom']};{utilisateur['prenom']};{utilisateur['email']};{utilisateur['telephone']};{plaques_str};{utilisateur['mot_de_passe']};{utilisateur['role']}\n")

def lire_config_utilisateur(email):
    fichier_config = os.path.join(DOSSIER_CONFIG, f"config_{email}.ini")
    config = configparser.ConfigParser()
    config.read(fichier_config)
    if 'Couleurs' not in config:
        config['Couleurs'] = {}
    return config

def ecrire_config_utilisateur(email, config):
    fichier_config = os.path.join(DOSSIER_CONFIG, f"config_{email}.ini")
    with open(fichier_config, 'w') as configfile:
        config.write(configfile)

def lire_config_par_defaut():
    config = configparser.ConfigParser()
    config.read(FICHIER_CONFIG_DEFAUT)
    if 'Couleurs' not in config:
        config['Couleurs'] = {}
    return config

def ecrire_config_par_defaut(config):
    with open(FICHIER_CONFIG_DEFAUT, 'w') as configfile:
        config.write(configfile)

def lire_config_login():
    config = configparser.ConfigParser()
    config.read(FICHIER_CONFIG_LOGIN)
    if 'Couleurs' not in config:
        config['Couleurs'] = {}
    return config

def ecrire_config_login(config):
    with open(FICHIER_CONFIG_LOGIN, 'w') as configfile:
        config.write(configfile)

def creer_utilisateur_par_defaut():
    utilisateurs = lire_utilisateurs()
    admin_existe = False
    for utilisateur in utilisateurs:
        if utilisateur['nom'] == 'admin' and utilisateur['prenom'] == 'admin':
            admin_existe = True
            break
    if not admin_existe:
        mot_de_passe_hache = generate_password_hash("admin", method='pbkdf2:sha256')
        utilisateurs.append({
            "nom": "admin",
            "prenom": "admin",
            "email": "admin@example.com",
            "telephone": "00.00.00.00.00",
            "plaque_immatriculation": "nothing",
            "mot_de_passe": mot_de_passe_hache,
            "role": "admin"
        })
        ecrire_utilisateurs(utilisateurs)

def lire_journal():
    """Lit le fichier journal et retourne une liste de dictionnaires."""
    journal = []
    try:
        with open("journal_plaques.log", "r") as f:
            for ligne in f:
                ligne = ligne.strip()
                if ligne:
                    horodatage, plaque = ligne.split(" : ")
                    journal.append({"horodatage": horodatage, "plaque": plaque})
    except FileNotFoundError:
        print("Fichier journal non trouvé.")
    return journal

def associer_plaque_utilisateur(plaques, utilisateurs):
    """Associe une plaque d'immatriculation à un utilisateur."""
    for utilisateur in utilisateurs:
        if "plaques_immatriculation" in utilisateur and plaques in utilisateur["plaques_immatriculation"]:
            return f"{utilisateur['prenom']} {utilisateur['nom']}"
    return "Inconnu"


def formater_plaque(plaque):
    """Formate une plaque d'immatriculation en AA-000-AA."""
    plaque = plaque.upper().replace("-", "")  # Convertit en majuscules et supprime les tirets existants
    if len(plaque) == 7:
        return f"{plaque[:2]}-{plaque[2:5]}-{plaque[5:]}"
    return plaque  # Retourne la plaque non modifiée si le format est incorrect

@app.before_request
def avant_requete():
    if 'utilisateur_connecte' in session:
        email = session['utilisateur_connecte']['email']
        config = lire_config_utilisateur(email)
        couleur_texte = config.get('Couleurs', 'couleur_texte', fallback=lire_config_par_defaut().get('Couleurs', 'couleur_texte', fallback='black'))
        session['couleur_texte'] = couleur_texte

with app.app_context():
    if not os.path.exists(DOSSIER_CONFIG):
        os.makedirs(DOSSIER_CONFIG)
    creer_utilisateur_par_defaut()

def envoyer_email(destinataire, sujet, message):
    expediteur = "btssnfourcade2@gmail.com"
    mot_de_passe_email = "wdkw adue hvub ikqm"

    msg = MIMEText(message)
    msg["Subject"] = sujet
    msg["From"] = expediteur
    msg["To"] = destinataire

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as serveur:
        serveur.login(expediteur, mot_de_passe_email)
        serveur.send_message(msg)

@app.route("/mot_de_passe_oublie", methods=["GET", "POST"])
def mot_de_passe_oublie():
    email_verification_needed = False
    email_error = None
    if request.method == "POST":
        if 'nom_utilisateur' in request.form:
            nom_utilisateur = request.form["nom_utilisateur"]
            utilisateurs = lire_utilisateurs()
            for utilisateur in utilisateurs:
                if f"{utilisateur['prenom']}.{utilisateur['nom']}" == nom_utilisateur:
                    session['nom_utilisateur_oublie'] = nom_utilisateur
                    email_verification_needed = True
                    break
            else:
                flash("Nom d'utilisateur introuvable.", "danger")
        elif 'email' in request.form:
            if 'nom_utilisateur_oublie' not in session:
                return redirect(url_for("mot_de_passe_oublie"))
            nom_utilisateur = session['nom_utilisateur_oublie']
            utilisateurs = lire_utilisateurs()
            utilisateur = next((u for u in utilisateurs if f"{u['prenom']}.{u['nom']}" == nom_utilisateur), None)
            if utilisateur and utilisateur['email'] == request.form['email']:
                nouveau_mot_de_passe = secrets.token_urlsafe(16)
                mot_de_passe_hache = generate_password_hash(nouveau_mot_de_passe, method='pbkdf2:sha256')
                utilisateur['mot_de_passe'] = mot_de_passe_hache
                ecrire_utilisateurs(utilisateurs)
                sujet = "Réinitialisation de votre mot de passe"
                message = f"Votre nouveau mot de passe est : {nouveau_mot_de_passe}"
                envoyer_email(utilisateur['email'], sujet, message)
                flash("Un email avec votre nouveau mot de passe a été envoyé.", "success")
                del session['nom_utilisateur_oublie']
                return redirect(url_for("login"))
            else:
                email_error = "Email incorrect."
                email_verification_needed = True
    return render_template("mot_de_passe_oublie.html", couleur_texte=session.get('couleur_texte', 'black'), email_verification_needed=email_verification_needed, email_error=email_error)

@app.route("/")
def index():
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))
    utilisateur = session['utilisateur_connecte']
    if check_password_hash(utilisateur['mot_de_passe'], 'admin'):
        flash("Veuillez changer votre mot de passe.", "danger")
    utilisateurs = lire_utilisateurs()
    logging.info(f"L'utilisateur {utilisateur['email']} ({request.remote_addr}) a accédé à la page d'accueil.")
    return render_template("index.html", utilisateurs=utilisateurs, couleur_texte=session.get('couleur_texte', 'black'))

@app.route("/ajouter", methods=["GET", "POST"])
def ajouter():
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))
    if session['utilisateur_connecte']['role'] != 'admin':
        flash("Vous n'avez pas les droits pour ajouter un utilisateur.", "danger")
        return redirect(url_for("index"))
    if request.method == "POST":
        nom = request.form["nom"]
        prenom = request.form["prenom"]
        email = request.form["email"]
        telephone = request.form["telephone"]
        # Modification ici
        plaques_str = request.form.get("plaques", "") # Utilisation de get pour eviter les erreurs si plaques est vide.
        plaques_list = [formater_plaque(plaque.strip()) for plaque in plaques_str.split(",") if plaque.strip()]
        # Fin de la modification
        mot_de_passe = request.form["mot_de_passe"]
        confirmation_mot_de_passe = request.form["confirmation_mot_de_passe"]
        role = request.form["role"]

        if mot_de_passe != confirmation_mot_de_passe:
            flash("Les mots de passe ne correspondent pas.", "danger")
            return render_template("ajouter.html", couleur_texte=session.get('couleur_texte', 'black'))

        mot_de_passe_hache = generate_password_hash(mot_de_passe, method='pbkdf2:sha256')

        utilisateurs = lire_utilisateurs()
        utilisateurs.append({
            "nom": nom,
            "prenom": prenom,
            "email": email,
            "telephone": telephone,
            "plaques_immatriculation": plaques_list, # Utilisation de la liste des plaques
            "mot_de_passe": mot_de_passe_hache,
            "role": role
        })
        ecrire_utilisateurs(utilisateurs)

        chemin_source = "static/images/default-fond.jpg"
        chemin_destination = f"static/images/fond_{email}.jpg"
        try:
            shutil.copyfile(chemin_source, chemin_destination)
            session['fond_cache_bust'] = str(time.time())
        except FileNotFoundError:
            print(f"Image d'arrière-plan par défaut non trouvée : {chemin_source}")
        logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) a ajouté l'utilisateur {email}.")
        return redirect(url_for("index"))
    logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) a accédé à la page d'ajout d'utilisateur.")
    return render_template("ajouter.html", couleur_texte=session.get('couleur_texte', 'black'))


@app.route("/journal")
def journal():
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))
    journal_entries = lire_journal()
    utilisateurs = lire_utilisateurs()
    for entry in journal_entries:
        entry["utilisateur"] = associer_plaque_utilisateur(entry["plaque"], utilisateurs)
    return render_template("journal.html", journal_entries=journal_entries, couleur_texte=session.get('couleur_texte', 'black'))

@app.route("/modifier/<int:id>", methods=["GET", "POST"])
def modifier(id):
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))
    utilisateurs = lire_utilisateurs()
    if id < 0 or id >= len(utilisateurs):
        return "Utilisateur non trouvé"
    utilisateur_a_modifier = utilisateurs[id]
    utilisateur_connecte = session['utilisateur_connecte']
    if utilisateur_connecte['role'] != 'admin' and utilisateur_connecte['email'] != utilisateur_a_modifier['email']:
        flash("Vous n'avez pas les droits pour modifier cet utilisateur.", "danger")
        return redirect(url_for("index"))
    if request.method == "POST":
        utilisateur_a_modifier["nom"] = request.form["nom"]
        utilisateur_a_modifier["prenom"] = request.form["prenom"]
        utilisateur_a_modifier["email"] = request.form["email"]
        utilisateur_a_modifier["telephone"] = request.form["telephone"]
        # Modification ici
        plaques_str = request.form.get("plaques", "") # Utilisation de get pour eviter les erreurs si plaques est vide.
        plaques_list = [formater_plaque(plaque.strip()) for plaque in plaques_str.split(",") if plaque.strip()]
        utilisateur_a_modifier["plaques_immatriculation"] = plaques_list
        # Fin de la modification
        mot_de_passe = request.form["mot_de_passe"]
        confirmation_mot_de_passe = request.form["confirmation_mot_de_passe"]

        if mot_de_passe:
            if mot_de_passe != confirmation_mot_de_passe:
                flash("Les mots de passe ne correspondent pas.", "danger")
                return render_template("modifier.html", utilisateur=utilisateur_a_modifier, id=id, couleur_texte=session.get('couleur_texte', 'black'))
            utilisateur_a_modifier["mot_de_passe"] = generate_password_hash(mot_de_passe, method='pbkdf2:sha256')
        if utilisateur_connecte['role'] == 'admin':
            utilisateur_a_modifier["role"] = request.form["role"]
        ecrire_utilisateurs(utilisateurs)
        logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) a modifié l'utilisateur {utilisateur_a_modifier['email']}.")
        return redirect(url_for("index"))
    logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) a accédé à la page de modification de l'utilisateur {utilisateur_a_modifier['email']}.")
    return render_template("modifier.html", utilisateur=utilisateur_a_modifier, id=id, couleur_texte=session.get('couleur_texte', 'black'))

@app.route("/supprimer/<int:id>")
def supprimer(id):
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))
    if session['utilisateur_connecte']['role'] != 'admin':
        flash("Vous n'avez pas les droits pour supprimer un utilisateur.", "danger")
        return redirect(url_for("index"))
    utilisateurs = lire_utilisateurs()
    if id < 0 or id >= len(utilisateurs):
        return "Utilisateur non trouvé"
    utilisateur_a_supprimer = utilisateurs.pop(id)
    ecrire_utilisateurs(utilisateurs)
    fichier_config = os.path.join(DOSSIER_CONFIG, f"config_{utilisateur_a_supprimer['email']}.ini")
    try:
        os.remove(fichier_config)
    except FileNotFoundError:
        print(f"Fichier de configuration non trouvé : {fichier_config}")
    logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) a supprimé l'utilisateur {utilisateur_a_supprimer['email']}.")
    return redirect(url_for("index"))

@app.route("/parametres", methods=["GET", "POST"])
def parametres():
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))
    utilisateurs = lire_utilisateurs()
    email = session['utilisateur_connecte']['email']
    utilisateur_connecte = session['utilisateur_connecte']

    config_defaut = lire_config_par_defaut()
    config_login = lire_config_login()

    if request.method == "POST":
        if 'image_fond' in request.files:
            image = request.files['image_fond']
            if image.content_type.startswith('image/'):
                if 'changer_fond_par_defaut' in request.form and utilisateur_connecte['role'] == 'admin':
                    chemin_image = f"static/images/default-fond.jpg"
                elif 'changer_fond_login' in request.form and utilisateur_connecte['role'] == 'admin':
                    chemin_image = f"static/images/login-fond.jpg"
                else:
                    chemin_image = f"static/images/fond_{email}.jpg"
                image.save(chemin_image)
                session['fond_cache_bust'] = str(time.time())
                flash("Fond d'écran changé avec succès!", "success")
        elif 'couleur_texte' in request.form:
            couleur_texte = request.form['couleur_texte']
            session['couleur_texte'] = couleur_texte

            config = lire_config_utilisateur(email)
            config.set('Couleurs', 'couleur_texte', couleur_texte)
            ecrire_config_utilisateur(email, config)

            flash("Couleur du texte changée avec succès!", "success")
        elif 'couleur_texte_defaut' in request.form and utilisateur_connecte['role'] == 'admin':
            couleur_texte_defaut = request.form['couleur_texte_defaut']
            config_defaut.set('Couleurs', 'couleur_texte', couleur_texte_defaut)
            ecrire_config_par_defaut(config_defaut)
            flash("Couleur du texte par défaut changée avec succès!", "success")
        elif 'couleur_texte_login' in request.form and utilisateur_connecte['role'] == 'admin':
            couleur_texte_login = request.form['couleur_texte_login']
            config_login.set('Couleurs', 'couleur_texte', couleur_texte_login)
            ecrire_config_login(config_login)
            flash("Couleur du texte de la page de connexion changée avec succès!", "success")
    logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) a accédé à la page de paramètres.")
    return render_template("parametres.html", fond_cache_bust=session.get('fond_cache_bust'), couleur_texte=session.get('couleur_texte'), utilisateurs=utilisateurs, utilisateur_connecte=utilisateur_connecte, couleur_texte_defaut=config_defaut.get('Couleurs', 'couleur_texte', fallback='black'), couleur_texte_login=config_login.get('Couleurs', 'couleur_texte', fallback='black'))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        nom_utilisateur = request.form["nom_utilisateur"]
        mot_de_passe = request.form["mot_de_passe"]
        utilisateurs = lire_utilisateurs()
        for utilisateur in utilisateurs:
            if f"{utilisateur['prenom']}.{utilisateur['nom']}" == nom_utilisateur:
                if check_password_hash(utilisateur['mot_de_passe'], mot_de_passe):
                    session['utilisateur_connecte'] = utilisateur
                    logging.info(f"L'utilisateur {utilisateur['email']} ({request.remote_addr}) s'est connecté.")
                    return redirect(url_for("index"))
        logging.warning(f"Tentative de connexion échouée depuis {request.remote_addr} avec le nom d'utilisateur {nom_utilisateur}.")
        return render_template("login.html", erreur="Nom d'utilisateur ou mot de passe incorrect", couleur_texte=lire_config_login().get('Couleurs', 'couleur_texte', fallback='black'))
    logging.info(f"Accès à la page de connexion depuis {request.remote_addr}.")
    return render_template("login.html", couleur_texte=lire_config_login().get('Couleurs', 'couleur_texte', fallback='black'))


@app.route("/logout")
def logout():
    if 'utilisateur_connecte' in session:
        logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) s'est déconnecté.")
        session.pop('utilisateur_connecte', None)
        session.clear()
        return redirect(url_for("login"))
    return redirect(url_for("login"))

if __name__ == "__main__":
    
    app.run(host='0.0.0.0', port=26000, debug=True)
