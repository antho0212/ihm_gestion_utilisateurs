pip install -r requirements.txt

pause

./start.bat