start http://127.0.0.1:26000

python app.py

pause
