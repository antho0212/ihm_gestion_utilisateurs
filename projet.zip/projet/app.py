from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import os
from werkzeug.security import generate_password_hash, check_password_hash
import time
import smtplib
from email.mime.text import MIMEText
import secrets
import configparser
import shutil # Keep shutil for potential file operations, though specific image copy is removed
import logging
import os
import json # Keep json in case it's used elsewhere or for future features
import datetime # Keep datetime in case it's used elsewhere or for future features

logging.basicConfig(level=logging.INFO)

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.static_folder = 'static'

FICHIER_UTILISATEURS = "utilisateurs.txt"
DOSSIER_CONFIG = "config"
FICHIER_CONFIG_DEFAUT = os.path.join(DOSSIER_CONFIG, "config_default.ini")
FICHIER_CONFIG_LOGIN = os.path.join(DOSSIER_CONFIG, "config_login.ini")

logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def lire_utilisateurs():
    utilisateurs = []
    if os.path.exists(FICHIER_UTILISATEURS):
        with open(FICHIER_UTILISATEURS, "r") as f:
            for ligne in f:
                ligne = ligne.strip()
                if ligne:
                    elements = ligne.split(";")
                    if len(elements) == 7:
                        nom, prenom, email, telephone, plaques, mot_de_passe, role = elements
                        plaques = plaques.split(",")
                        utilisateurs.append({
                            "nom": nom,
                            "prenom": prenom,
                            "email": email,
                            "telephone": telephone,
                            "plaques_immatriculation": plaques,
                            "mot_de_passe": mot_de_passe,
                            "role": role
                        })
    return utilisateurs

def ecrire_utilisateurs(utilisateurs):
    with open(FICHIER_UTILISATEURS, "w") as f:
        for utilisateur in utilisateurs:
            plaques_str = ",".join(utilisateur['plaques_immatriculation'])
            f.write(f"{utilisateur['nom']};{utilisateur['prenom']};{utilisateur['email']};{utilisateur['telephone']};{plaques_str};{utilisateur['mot_de_passe']};{utilisateur['role']}\n")

def lire_config_utilisateur(email):
    fichier_config = os.path.join(DOSSIER_CONFIG, f"config_{email}.ini")
    config = configparser.ConfigParser()
    config.read(fichier_config)
    # Assurer la présence des sections même si le fichier est vide ou n'existe pas encore
    if 'Couleurs' not in config:
        config['Couleurs'] = {}
    # La section 'Preferences' n'est plus pertinente si les thèmes sont fixes, mais la gardons pour la robustesse
    if 'Preferences' not in config:
        config['Preferences'] = {}
    return config

def ecrire_config_utilisateur(email, config):
    fichier_config = os.path.join(DOSSIER_CONFIG, f"config_{email}.ini")
    with open(fichier_config, 'w') as configfile:
        config.write(configfile)

def lire_config_par_defaut():
    config = configparser.ConfigParser()
    config.read(FICHIER_CONFIG_DEFAUT)
    if 'Couleurs' not in config:
        config['Couleurs'] = {}
    return config

def ecrire_config_par_defaut(config):
    with open(FICHIER_CONFIG_DEFAUT, 'w') as configfile:
        config.write(configfile)

def lire_config_login():
    config = configparser.ConfigParser()
    config.read(FICHIER_CONFIG_LOGIN)
    if 'Couleurs' not in config:
        config['Couleurs'] = {}
    return config

def ecrire_config_login(config):
    with open(FICHIER_CONFIG_LOGIN, 'w') as configfile:
        config.write(configfile)

def creer_utilisateur_par_defaut():
    utilisateurs = lire_utilisateurs()
    admin_existe = False
    for utilisateur in utilisateurs:
        if utilisateur['nom'] == 'admin' and utilisateur['prenom'] == 'admin':
            admin_existe = True
            break
    if not admin_existe:
        mot_de_passe_hache = generate_password_hash("admin", method='pbkdf2:sha256')
        utilisateurs.append({
            "nom": "admin",
            "prenom": "admin",
            "email": "admin@example.com",
            "telephone": "00.00.00.00.00",
            "plaques_immatriculation": ["nothing"],
            "mot_de_passe": mot_de_passe_hache,
            "role": "admin"
        })
        ecrire_utilisateurs(utilisateurs)

def lire_journal():
    journal = []
    try:
        with open("journal_plaques.log", "r") as f:
            for ligne in f:
                ligne = ligne.strip()
                if ligne:
                    horodatage, plaque = ligne.split(" : ")
                    journal.append({"horodatage": horodatage, "plaque": plaque})
    except FileNotFoundError:
        print("Fichier journal non trouvé.")
    return journal

def associer_plaque_utilisateur(plaques, utilisateurs):
    for utilisateur in utilisateurs:
        if "plaques_immatriculation" in utilisateur and plaques in utilisateur["plaques_immatriculation"]:
            return f"{utilisateur['prenom']} {utilisateur['nom']}"
    return "Inconnu"

def formater_plaque(plaque):
    plaque = plaque.upper().replace("-", "")
    if len(plaque) == 7 and plaque[:2].isalpha() and plaque[2:5].isdigit() and plaque[5:].isalpha():
        return f"{plaque[:2]}-{plaque[2:5]}-{plaque[5:]}"
    elif len(plaque) == 6 and plaque[:3].isdigit() and plaque[3:].isalpha():
        return f"{plaque[:3]}-{plaque[3:]}"
    elif len(plaque) == 8 and plaque[:4].isdigit() and plaque[4:].isalpha():
        return f"{plaque[:4]}-{plaque[4:]}"
    return plaque

@app.before_request
def avant_requete():
    """Exécute cette fonction avant chaque requête et définit le thème Galaxy."""
    # Le thème est toujours 'theme-galaxy'
    session['theme'] = 'theme-galaxy'
    # Suppression de session['theme_data'] qui n'est plus utilisée

    if 'utilisateur_connecte' in session:
        email = session['utilisateur_connecte']['email']
        config = lire_config_utilisateur(email)
        session['couleur_texte'] = config.get('Couleurs', 'couleur_texte', fallback=lire_config_par_defaut().get('Couleurs', 'couleur_texte', fallback='black'))
    else:
        session['couleur_texte'] = lire_config_login().get('Couleurs', 'couleur_texte', fallback='black')

with app.app_context():
    if not os.path.exists(DOSSIER_CONFIG):
        os.makedirs(DOSSIER_CONFIG)
    creer_utilisateur_par_defaut()

def envoyer_email(destinataire, sujet, message):
    expediteur = "btssnfourcade2@gmail.com"
    # Il est fortement recommandé d'utiliser des variables d'environnement ou un fichier de configuration
    # sécurisé pour ce mot de passe d'application, plutôt que de le laisser en clair dans le code.
    mot_de_passe_email = "qvxt dirt ztwu garx" 

    msg = MIMEText(message)
    msg["Subject"] = sujet
    msg["From"] = expediteur
    msg["To"] = destinataire

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as serveur:
            serveur.login(expediteur, mot_de_passe_email)
            serveur.send_message(msg)
        return True
    except Exception as e:
        logging.error(f"Erreur lors de l'envoi de l'e-mail à {destinataire}: {e}")
        return False

@app.route("/")
def index():
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))
    utilisateur = session['utilisateur_connecte']
    if check_password_hash(utilisateur['mot_de_passe'], 'admin'):
        flash("Veuillez changer votre mot de passe.", "danger")
    utilisateurs = lire_utilisateurs()
    logging.info(f"L'utilisateur {utilisateur['email']} ({request.remote_addr}) a accédé à la page d'accueil.")
    return render_template("index.html", utilisateurs=utilisateurs, couleur_texte=session.get('couleur_texte', 'black'), current_theme_class=session.get('theme'))

@app.route("/ajouter", methods=["GET", "POST"])
def ajouter():
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))
    if session['utilisateur_connecte']['role'] != 'admin':
        flash("Vous n'avez pas les droits pour ajouter un utilisateur.", "danger")
        return redirect(url_for("index"))
    if request.method == "POST":
        nom = request.form["nom"]
        prenom = request.form["prenom"]
        email = request.form["email"]
        telephone = request.form["telephone"]
        plaques_str = request.form.get("plaques", "")
        mot_de_passe = request.form["mot_de_passe"]
        confirmation_mot_de_passe = request.form["confirmation_mot_de_passe"]
        role = request.form["role"]

        if mot_de_passe != confirmation_mot_de_passe:
            flash("Les mots de passe ne correspondent pas.", "danger")
            return render_template("ajouter.html", couleur_texte=session.get('couleur_texte', 'black'), current_theme_class=session.get('theme'))

        mot_de_passe_hache = generate_password_hash(mot_de_passe, method='pbkdf2:sha256')

        utilisateurs = lire_utilisateurs()
        if any(u['email'] == email for u in utilisateurs):
            flash("Un utilisateur avec cet email existe déjà.", "danger")
            return render_template("ajouter.html", couleur_texte=session.get('couleur_texte', 'black'), current_theme_class=session.get('theme'))

        plaques_list = [formater_plaque(plaque.strip()) for plaque in plaques_str.split(",") if plaque.strip()]

        utilisateurs.append({
            "nom": nom,
            "prenom": prenom,
            "email": email,
            "telephone": telephone,
            "plaques_immatriculation": plaques_list,
            "mot_de_passe": mot_de_passe_hache,
            "role": role
        })
        ecrire_utilisateurs(utilisateurs)

        # Create a default config file for the new user
        config_utilisateur = configparser.ConfigParser()
        config_utilisateur['Couleurs'] = {'couleur_texte': 'black'}
        # La section 'Preferences' n'est plus nécessaire si les thèmes sont fixes, mais pour la robustesse
        config_utilisateur['Preferences'] = {}
        ecrire_config_utilisateur(email, config_utilisateur)


        flash("Utilisateur ajouté avec succès!", "success")
        logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) a ajouté l'utilisateur {email}.")
        return redirect(url_for("parametres"))

    logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) a accédé à la page d'ajout d'utilisateur.")
    return render_template("ajouter.html", couleur_texte=session.get('couleur_texte', 'black'), current_theme_class=session.get('theme'))

@app.route("/journal")
def journal():
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))
    journal_entries = lire_journal()
    utilisateurs = lire_utilisateurs()
    for entry in journal_entries:
        entry["utilisateur"] = associer_plaque_utilisateur(entry["plaque"], utilisateurs)
    return render_template("journal.html", journal_entries=journal_entries, couleur_texte=session.get('couleur_texte', 'black'), current_theme_class=session.get('theme'))

@app.route("/modifier/<int:id>", methods=["GET", "POST"])
def modifier(id):
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))
    utilisateurs = lire_utilisateurs()
    if id < 0 or id >= len(utilisateurs):
        flash("Utilisateur non trouvé.", "danger")
        return redirect(url_for("parametres"))
    
    utilisateur_a_modifier = utilisateurs[id]
    utilisateur_connecte = session['utilisateur_connecte']

    if utilisateur_connecte['role'] != 'admin' and utilisateur_connecte['email'] != utilisateur_a_modifier['email']:
        flash("Vous n'avez pas les droits pour modifier cet utilisateur.", "danger")
        return redirect(url_for("index"))
    
    if utilisateur_connecte['role'] != 'admin' and request.method == 'POST' and 'role' in request.form and request.form['role'] != utilisateur_a_modifier['role']:
        flash("Vous ne pouvez pas modifier votre propre rôle.", "danger")
        return redirect(url_for("modifier", id=id))

    if request.method == "POST":
        original_email = utilisateur_a_modifier['email']

        utilisateur_a_modifier["nom"] = request.form["nom"]
        utilisateur_a_modifier["prenom"] = request.form["prenom"]
        new_email = request.form["email"]
        utilisateur_a_modifier["telephone"] = request.form["telephone"]
        
        plaques_str = request.form.get("plaques", "")
        plaques_list = [formater_plaque(plaque.strip()) for plaque in plaques_str.split(",") if plaque.strip()]
        utilisateur_a_modifier["plaques_immatriculation"] = plaques_list
        
        mot_de_passe = request.form["mot_de_passe"]
        confirmation_mot_de_passe = request.form["confirmation_mot_de_passe"]

        if new_email != original_email and any(u['email'] == new_email for u in utilisateurs):
            flash("Un autre utilisateur avec cet email existe déjà.", "danger")
            return render_template("modifier.html", utilisateur=utilisateur_a_modifier, id=id, couleur_texte=session.get('couleur_texte', 'black'), current_theme_class=session.get('theme'))
        
        utilisateur_a_modifier["email"] = new_email

        if mot_de_passe:
            if mot_de_passe != confirmation_mot_de_passe:
                flash("Les mots de passe ne correspondent pas.", "danger")
                return render_template("modifier.html", utilisateur=utilisateur_a_modifier, id=id, couleur_texte=session.get('couleur_texte', 'black'), current_theme_class=session.get('theme'))
            utilisateur_a_modifier["mot_de_passe"] = generate_password_hash(mot_de_passe, method='pbkdf2:sha256')
        
        if utilisateur_connecte['role'] == 'admin':
            utilisateur_a_modifier["role"] = request.form["role"]
        
        ecrire_utilisateurs(utilisateurs)

        # Renomme le fichier de config si l'email a changé
        if new_email != original_email:
            old_config_path = os.path.join(DOSSIER_CONFIG, f"config_{original_email}.ini")
            new_config_path = os.path.join(DOSSIER_CONFIG, f"config_{new_email}.ini")
            if os.path.exists(old_config_path):
                os.rename(old_config_path, new_config_path)

            if session['utilisateur_connecte']['email'] == original_email:
                session['utilisateur_connecte']['email'] = new_email
                config = lire_config_utilisateur(new_email)
                session['couleur_texte'] = config.get('Couleurs', 'couleur_texte', fallback='black')

        flash("Utilisateur modifié avec succès!", "success")
        logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) a modifié l'utilisateur {utilisateur_a_modifier['email']}.")
        return redirect(url_for("parametres"))
    
    logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) a accédé à la page de modification de l'utilisateur {utilisateur_a_modifier['email']}.")
    return render_template("modifier.html", utilisateur=utilisateur_a_modifier, id=id, couleur_texte=session.get('couleur_texte', 'black'), current_theme_class=session.get('theme'))

@app.route("/supprimer/<int:id>")
def supprimer(id):
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))
    if session['utilisateur_connecte']['role'] != 'admin':
        flash("Vous n'avez pas les droits pour supprimer un utilisateur.", "danger")
        return redirect(url_for("index"))
    
    utilisateurs = lire_utilisateurs()
    if id < 0 or id >= len(utilisateurs):
        flash("Utilisateur non trouvé.", "danger")
        return redirect(url_for("parametres"))
    
    utilisateur_a_supprimer = utilisateurs[id]
    
    if utilisateur_a_supprimer['email'] == session['utilisateur_connecte']['email']:
        flash("Un administrateur ne peut pas se supprimer lui-même.", "danger")
        return redirect(url_for("parametres"))

    utilisateurs.pop(id)
    ecrire_utilisateurs(utilisateurs)
    
    fichier_config = os.path.join(DOSSIER_CONFIG, f"config_{utilisateur_a_supprimer['email']}.ini")
    try:
        os.remove(fichier_config)
    except FileNotFoundError:
        print(f"Fichier de configuration non trouvé : {fichier_config}")
    

    flash("Utilisateur supprimé avec succès!", "success")
    logging.info(f"L'utilisateur {session['utilisateur_connecte']['email']} ({request.remote_addr}) a supprimé l'utilisateur {utilisateur_a_supprimer['email']}.")
    return redirect(url_for("parametres"))

@app.route("/parametres", methods=["GET", "POST"])
def parametres():
    if 'utilisateur_connecte' not in session:
        return redirect(url_for("login"))

    email = session['utilisateur_connecte']['email']
    utilisateur_connecte = session['utilisateur_connecte']

    config_defaut = lire_config_par_defaut()
    config_login = lire_config_login()

    if request.method == "POST":
        if utilisateur_connecte['role'] == 'admin':
            if 'couleur_texte_defaut' in request.form:
                couleur_texte_defaut = request.form['couleur_texte_defaut']
                config_defaut.set('Couleurs', 'couleur_texte', couleur_texte_defaut)
                ecrire_config_par_defaut(config_defaut)
                flash("Couleur du texte par défaut mise à jour!", "success")
            
            if 'couleur_texte_login' in request.form:
                couleur_texte_login = request.form['couleur_texte_login']
                config_login.set('Couleurs', 'couleur_texte', couleur_texte_login)
                ecrire_config_login(config_login)
                flash("Couleur du texte de la page de connexion mise à jour!", "success")
            
            logging.info(f"L'administrateur {email} ({request.remote_addr}) a modifié les paramètres administrateur.")
            return redirect(url_for("parametres"))
        
        flash("Action non autorisée.", "danger")
        return redirect(url_for("parametres"))

    return render_template("parametres.html",
                            # Suppression de fond_cache_bust, plus utilisé
                            couleur_texte=session.get('couleur_texte'),
                            utilisateurs=lire_utilisateurs(),
                            utilisateur_connecte=utilisateur_connecte,
                            couleur_texte_defaut=config_defaut.get('Couleurs', 'couleur_texte', fallback='black'),
                            couleur_texte_login=config_login.get('Couleurs', 'couleur_texte', fallback='black'),
                            current_theme_class=session.get('theme'))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        nom_utilisateur = request.form["nom_utilisateur"]
        mot_de_passe = request.form["mot_de_passe"]
        utilisateurs = lire_utilisateurs()
        for utilisateur in utilisateurs:
            if f"{utilisateur['prenom']}.{utilisateur['nom']}" == nom_utilisateur:
                if check_password_hash(utilisateur['mot_de_passe'], mot_de_passe):
                    session['utilisateur_connecte'] = utilisateur
                    logging.info(f"L'utilisateur {utilisateur['email']} ({request.remote_addr}) s'est connecté.")
                    return redirect(url_for("index"))
        logging.warning(f"Tentative de connexion échouée depuis {request.remote_addr} avec le nom d'utilisateur {nom_utilisateur}.")
        return render_template("login.html", erreur="Nom d'utilisateur ou mot de passe incorrect", couleur_texte=lire_config_login().get('Couleurs', 'couleur_texte', fallback='black'), current_theme_class='theme-galaxy')

    logging.info(f"Accès à la page de connexion depuis {request.remote_addr}.")
    return render_template("login.html", erreur=None, couleur_texte=lire_config_login().get('Couleurs', 'couleur_texte', fallback='black'), current_theme_class='theme-galaxy')

@app.route("/logout")
def logout():
    session.pop('utilisateur_connecte', None)
    session.pop('theme', None)
    # Suppression de session.pop('theme_data', None)
    session.clear() # S'assure que toutes les données de session sont nettoyées
    return redirect(url_for("login"))

@app.route("/mot_de_passe_oublie", methods=["GET", "POST"])
def mot_de_passe_oublie():
    couleur_texte = session.get('couleur_texte', 'black')
    config_login = lire_config_login()

    if 'utilisateur_connecte' not in session:
        couleur_texte = config_login.get('Couleurs', 'couleur_texte', fallback='black')

    if request.method == "POST":
        logging.info("Requête POST reçue sur /mot_de_passe_oublie.")

        # --- Logique de l'étape 1 : Soumission du nom d'utilisateur ---
        if "nom_utilisateur" in request.form and "email" not in request.form and "reset_method" not in request.form:
            nom_utilisateur = request.form["nom_utilisateur"]
            logging.info(f"Étape 1: Nom d'utilisateur soumis: '{nom_utilisateur}'.")
            
            utilisateurs = lire_utilisateurs()
            found_user = None
            for utilisateur in utilisateurs:
                if f"{utilisateur['prenom']}.{utilisateur['nom']}" == nom_utilisateur:
                    found_user = utilisateur
                    break
            
            if found_user:
                logging.info(f"Étape 1: Utilisateur '{nom_utilisateur}' trouvé. Préparation de l'étape 2.")
                session['reset_username_found'] = nom_utilisateur 
                session['reset_user_email_found'] = found_user['email']
                flash("Veuillez confirmer votre adresse email et choisir une méthode de réinitialisation.", "info")
                return render_template("mot_de_passe_oublie.html", 
                                       email_verification_needed=True,
                                       couleur_texte=couleur_texte,
                                       current_theme_class=session.get('theme'),
                                       nom_utilisateur_prefill=nom_utilisateur,
                                       email_prefill=found_user['email'])
            else:
                logging.warning(f"Étape 1: Nom d'utilisateur '{nom_utilisateur}' non trouvé dans la base de données.")
                flash("Nom d'utilisateur non trouvé.", "danger")
                return render_template("mot_de_passe_oublie.html", 
                                       email_verification_needed=False,
                                       couleur_texte=couleur_texte,
                                       current_theme_class=session.get('theme'))

        # --- Logique de l'étape 2 : Confirmation email et choix de la méthode ---
        elif "email" in request.form and "reset_method" in request.form: 
            email_saisi = request.form["email"]
            reset_method = request.form["reset_method"]
            
            nom_utilisateur_session = session.pop('reset_username_found', None) 
            user_email_session = session.pop('reset_user_email_found', None) 

            logging.info(f"Étape 2: Email saisi: '{email_saisi}', Méthode choisie: '{reset_method}'.")
            logging.info(f"Étape 2: Données session: nom_utilisateur='{nom_utilisateur_session}', email='{user_email_session}'.")

            if not nom_utilisateur_session or not user_email_session or email_saisi != user_email_session:
                logging.error("Étape 2: Données de session invalides ou incohérentes (nom utilisateur ou email).")
                flash("Requête de réinitialisation invalide ou expirée. Veuillez recommencer.", "danger")
                return redirect(url_for("mot_de_passe_oublie"))

            utilisateurs = lire_utilisateurs()
            found_user = None
            for utilisateur in utilisateurs:
                if (f"{utilisateur['prenom']}.{utilisateur['nom']}" == nom_utilisateur_session and 
                    utilisateur['email'] == email_saisi):
                    found_user = utilisateur
                    break
            
            if not found_user:
                logging.warning(f"Étape 2: Utilisateur non trouvé ou email incorrect pour '{nom_utilisateur_session}' avec email '{email_saisi}'.")
                flash("Nom d'utilisateur et/ou email non trouvés ou incorrects.", "danger")
                return render_template("mot_de_passe_oublie.html", 
                                       email_verification_needed=False, 
                                       couleur_texte=couleur_texte,
                                       current_theme_class=session.get('theme'))

            logging.info(f"Étape 2: Utilisateur '{found_user['email']}' confirmé pour la réinitialisation.")

            # --- Traitement selon la méthode choisie ---
            if reset_method == "random_password":
                logging.info(f"Méthode choisie: Génération d'un mot de passe aléatoire pour '{found_user['email']}'.")
                new_random_password = secrets.token_urlsafe(10)

                for i, user in enumerate(utilisateurs):
                    if user['email'] == found_user['email']:
                        utilisateurs[i]['mot_de_passe'] = generate_password_hash(new_random_password, method='pbkdf2:sha256')
                        break
                ecrire_utilisateurs(utilisateurs)

                sujet = "Votre nouveau mot de passe"
                message = f"""Bonjour {found_user['prenom']} {found_user['nom']},

Votre nouveau mot de passe pour le système est : {new_random_password}

Nous vous recommandons de le changer après votre première connexion pour des raisons de sécurité.

Si vous n'avez pas demandé cette réinitialisation, veuillez ignorer cet e-mail.

Cordialement,
Votre équipe de support
"""
                try:
                    if envoyer_email(found_user['email'], sujet, message):
                        flash("Un nouveau mot de passe a été envoyé à votre adresse e-mail.", "success")
                        logging.info(f"Succès: Nouveau mot de passe généré et envoyé à '{found_user['email']}'.")
                        return redirect(url_for("login"))
                    else:
                        flash("Erreur lors de l'envoi du nouveau mot de passe. Veuillez réessayer plus tard.", "danger")
                        logging.error(f"Échec: envoyer_email a retourné False pour '{found_user['email']}' (mot de passe aléatoire).")
                        return render_template("mot_de_passe_oublie.html", 
                                               email_verification_needed=True, 
                                               couleur_texte=couleur_texte,
                                               current_theme_class=session.get('theme'),
                                               nom_utilisateur_prefill=nom_utilisateur_session,
                                               email_prefill=email_saisi)
                except Exception as e:
                    logging.error(f"ERREUR CRITIQUE: Exception lors de l'envoi du mot de passe aléatoire à '{found_user['email']}': {e}")
                    flash("Une erreur interne est survenue lors de l'envoi du mot de passe. Veuillez contacter l'administrateur.", "danger")
                    return render_template("mot_de_passe_oublie.html", 
                                           email_verification_needed=True, 
                                           couleur_texte=couleur_texte,
                                           current_theme_class=session.get('theme'),
                                           nom_utilisateur_prefill=nom_utilisateur_session,
                                           email_prefill=email_saisi)

            elif reset_method == "reset_link":
                logging.info(f"Méthode choisie: Envoi d'un lien de réinitialisation pour '{found_user['email']}'.")
                if not hasattr(app, 'RESET_TOKENS'):
                    app.RESET_TOKENS = {}
                
                reset_token = secrets.token_urlsafe(32)
                app.RESET_TOKENS[reset_token] = {
                    'email': found_user['email'],
                    'expires': time.time() + 3600 # Jeton expire dans 1 heure (3600 secondes)
                }
                reset_link = url_for('reinitialiser_mot_de_passe', token=reset_token, _external=True)

                sujet = "Réinitialisation de votre mot de passe"
                message = f"""Bonjour {found_user['prenom']} {found_user['nom']},

Vous avez demandé à réinitialiser votre mot de passe. Cliquez sur le lien suivant pour choisir un nouveau mot de passe :

{reset_link}

Ce lien expirera dans 1 heure.

Si vous n'avez pas demandé cette réinitialisation, veuillez ignorer cet e-mail.

Cordialement,
Votre équipe de support
"""
                try:
                    if envoyer_email(found_user['email'], sujet, message):
                        flash("Un lien de réinitialisation a été envoyé à votre adresse e-mail.", "success")
                        logging.info(f"Succès: Lien de réinitialisation envoyé à '{found_user['email']}'.")
                        return redirect(url_for("login"))
                    else:
                        flash("Erreur lors de l'envoi de l'e-mail de réinitialisation. Veuillez réessayer plus tard.", "danger")
                        logging.error(f"Échec: envoyer_email a retourné False pour '{found_user['email']}' (lien de réinitialisation).")
                        return render_template("mot_de_passe_oublie.html", 
                                               email_verification_needed=True, 
                                               couleur_texte=couleur_texte,
                                               current_theme_class=session.get('theme'),
                                               nom_utilisateur_prefill=nom_utilisateur_session,
                                               email_prefill=email_saisi)
                except Exception as e:
                    logging.error(f"ERREUR CRITIQUE: Exception lors de l'envoi du lien de réinitialisation à '{found_user['email']}': {e}")
                    flash("Une erreur interne est survenue lors de l'envoi du lien. Veuillez contacter l'administrateur.", "danger")
                    return render_template("mot_de_passe_oublie.html", 
                                           email_verification_needed=True, 
                                           couleur_texte=couleur_texte,
                                           current_theme_class=session.get('theme'),
                                           nom_utilisateur_prefill=nom_utilisateur_session,
                                           email_prefill=email_saisi)
            else:
                logging.warning(f"Méthode de réinitialisation invalide choisie: '{reset_method}'.")
                flash("Méthode de réinitialisation invalide.", "danger")
                return render_template("mot_de_passe_oublie.html", 
                                       email_verification_needed=True, 
                                       couleur_texte=couleur_texte,
                                       current_theme_class=session.get('theme'),
                                       nom_utilisateur_prefill=nom_utilisateur_session,
                                       email_prefill=email_saisi)
        else:
            logging.warning("Requête POST inattendue sur /mot_de_passe_oublie (paramètres manquants).")
            flash("Requête invalide pour la réinitialisation de mot de passe.", "danger")
            return redirect(url_for("mot_de_passe_oublie"))

    logging.info("Requête GET reçue sur /mot_de_passe_oublie. Affichage du formulaire.")
    return render_template("mot_de_passe_oublie.html", 
                           email_verification_needed=session.get('reset_username_found') is not None, 
                           couleur_texte=couleur_texte,
                           current_theme_class=session.get('theme'),
                           nom_utilisateur_prefill=session.get('reset_username_found'),
                           email_prefill=session.get('reset_user_email_found'))

@app.route("/reinitialiser_mot_de_passe/<token>", methods=["GET", "POST"])
def reinitialiser_mot_de_passe(token):
    couleur_texte = session.get('couleur_texte', 'black')

    logging.info(f"Accès à /reinitialiser_mot_de_passe avec le jeton: {token}")
    
    if not hasattr(app, 'RESET_TOKENS'):
        app.RESET_TOKENS = {}

    token_data = app.RESET_TOKENS.get(token)

    if not token_data or token_data['expires'] < time.time():
        logging.warning(f"Jeton '{token}' invalide ou expiré.")
        flash("Le lien de réinitialisation est invalide ou a expiré. Veuillez refaire une demande.", "danger")
        return redirect(url_for("mot_de_passe_oublie"))

    user_email_from_token = token_data['email']
    utilisateurs = lire_utilisateurs()
    found_user = None
    for utilisateur in utilisateurs:
        if utilisateur['email'] == user_email_from_token:
            found_user = utilisateur
            break

    if not found_user:
        logging.error(f"Utilisateur correspondant à l'email du jeton '{user_email_from_token}' non trouvé dans la base de données.")
        flash("Utilisateur non trouvé pour ce lien de réinitialisation.", "danger")
        return redirect(url_for("mot_de_passe_oublie"))

    if request.method == "POST":
        logging.info(f"Requête POST pour réinitialiser le mot de passe de '{found_user['email']}'.")
        new_password = request.form["new_password"]
        confirm_password = request.form["confirm_password"]

        if not new_password or not confirm_password:
            flash("Veuillez saisir et confirmer le nouveau mot de passe.", "danger")
            return render_template("reinitialiser_mot_de_passe.html", token=token, couleur_texte=couleur_texte, current_theme_class=session.get('theme'))

        if new_password != confirm_password:
            logging.warning(f"Mots de passe non correspondants pour '{found_user['email']}'.")
            flash("Les mots de passe ne correspondent pas.", "danger")
            return render_template("reinitialiser_mot_de_passe.html", token=token, couleur_texte=couleur_texte, current_theme_class=session.get('theme'))

        if len(new_password) < 6:
            logging.warning(f"Nouveau mot de passe trop court pour '{found_user['email']}'.")
            flash("Le nouveau mot de passe doit contenir au moins 6 caractères.", "danger")
            return render_template("reinitialiser_mot_de_passe.html", token=token, couleur_texte=couleur_texte, current_theme_class=session.get('theme'))

        for i, user in enumerate(utilisateurs):
            if user['email'] == found_user['email']:
                utilisateurs[i]['mot_de_passe'] = generate_password_hash(new_password, method='pbkdf2:sha256')
                break
        ecrire_utilisateurs(utilisateurs)

        if token in app.RESET_TOKENS:
            del app.RESET_TOKENS[token]
        logging.info(f"Mot de passe de l'utilisateur '{found_user['email']}' réinitialisé et jeton '{token}' supprimé.")

        flash("Votre mot de passe a été réinitialisé avec succès. Vous pouvez maintenant vous connecter.", "success")
        return redirect(url_for("login"))

    logging.info(f"Affichage du formulaire de réinitialisation pour le jeton '{token}'.")
    return render_template("reinitialiser_mot_de_passe.html", token=token, couleur_texte=couleur_texte, current_theme_class=session.get('theme'))


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=26000, debug=True)